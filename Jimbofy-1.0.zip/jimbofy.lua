--- STEAMODDED HEADER
--- MOD_NAME: Jimbofy
--- MOD_ID: jimbofy
--- MOD_AUTHOR: [Beave]
--- MOD_DESCRIPTION: Heralds the Great Jimbo Takeover of '26

----------------------------------------------
------------------ MOD CODE ------------------
----------------------------------------------

local function init()
    -- List of all localization tables to sweep
    local tables_to_check = {
        G.localization.descriptions.Joker,
        G.localization.descriptions.Tarot,
        G.localization.descriptions.Voucher,
        G.localization.descriptions.Spectral,
        G.localization.descriptions.Other -- Stickers, tooltips & pack descriptions
    }

    -- Global sweep, replaces all mentions of "Joker" with "Jimbo" and "joker" with "jimbo"
    for _, tbl in ipairs(tables_to_check) do
        for k, v in pairs(tbl) do
            if v.name then
                v.name = v.name:gsub("Joker", "Jimbo"):gsub("joker", "jimbo")
            end
            if v.text then
                for line_num, line_text in ipairs(v.text) do
                    v.text[line_num] = line_text:gsub("Joker", "Jimbo"):gsub("joker", "jimbo")
                end
            end
        end
    end

    -- Affects UI and dictionary (Buttons, Labels, etc.)
    for k, v in pairs(G.localization.misc.dictionary) do
        if type(v) == "string" then
            G.localization.misc.dictionary[k] = v:gsub("Joker", "Jimbo"):gsub("joker", "jimbo")
        end
    end

    -- Affects Buffoon Packs
    local pack_keys = {'p_buffoon_norm', 'p_buffoon_mega', 'p_buffoon_jumbo'}
    for _, key in ipairs(pack_keys) do
        if G.localization.descriptions.Other[key] and G.localization.descriptions.Other[key].text then
            for line_num, line_text in ipairs(G.localization.descriptions.Other[key].text) do
                G.localization.descriptions.Other[key].text[line_num] = line_text:gsub("Joker", "Jimbo"):gsub("joker", "jimbo")
            end
        end
    end

    -- Renames specifically the OG Joker
    G.localization.descriptions.Joker["j_joker"].name = "The One And Only Jimbo"


    sendDebugMessage("Jimbofy :: The era of the Joker is over. All hail Jimbo.")
end

if SMODS.current_mod then
    SMODS.current_mod.process_loc_text = init
else
    init()
end